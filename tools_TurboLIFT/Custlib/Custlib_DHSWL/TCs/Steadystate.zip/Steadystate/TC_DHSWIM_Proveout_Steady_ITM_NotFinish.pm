#### TEST CASE MODULE
package TC_DHSWIM_Proveout_Steady_ITM_NotFinish;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.1 $;
our $HEADER = q$Header: Include/TCpmGenerator/Create_TCpm.pl 1.1 2015/01/21 16:00:45MEZ Geisler Martin (CC-PS/EPS2) (gem1si) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: <TS name> (e.g. TS_SWM_SwitchMgt)
#TS version in DOORS: <TS version based on which this script is written/updated> (e.g. 3.30)
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project; #necessary
#include further modules here

##################################

our $PURPOSE = "<summarize what this test is good for>";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_DHSWIM_Proveout_Steady_ITM_NotFinish

=head1 PURPOSE

<explain what this test is good for>

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. Set The voltage to <Voltage> and check fault recorder.

2. Create <Fault> condition to keep ECU in ITM mode after <ProveOut_Time> and wait for <Fault_Qua_Time>.

3. Reset ECU.

4. Wait for <ProveOut_Time>

5. Check fault recorder.

6. Check ECU mode.

7. Check state of <DHSWL_signal> at <ProveOut_Time> continuously from IGN ON.


I<B<Evaluation>>

1. <Fault_Voltage> is in <Fault_Voltage_state>.

2.

3.

4.

5. <Fault> is in <Fault_state> and <Fault_Voltage> in <Fault_Voltage_State>.

6. ECU goes to ITM mode.

7. <DHSWL_signal> shall be 0x1.


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'purpose' => 
	SCALAR 'Voltage' => 
	SCALAR 'Fault' => 
	SCALAR 'Fault_state' => 
	SCALAR 'Fault_Qua_Time' => 
	SCALAR 'Fault_Voltage' => 
	SCALAR 'Fault_Voltage_State' => 
	SCALAR 'ProveOut_Time' => 
	SCALAR 'DHSWL_signal' => 


=head2 PARAMETER EXAMPLES

	purpose = 'check behavior of DHSWL after Proveout time if ITM mode is not finished'
	
	Voltage = '<Test Heading>'
	Fault = 'rb_swm_OpenLineSPSFD_flt'
	Fault_state = 'Qualified'
	Fault_Qua_Time = '2000' #ms
	Fault_Voltage = 'No fault'
	Fault_Voltage_State = 'Empty'
	ProveOut_Time = '8000' #ms  (+/-300ms)
	DHSWL_signal = 'DHS_RILReq'

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_Voltage;
my $tcpar_Fault;
my $tcpar_Fault_state;
my $tcpar_Fault_Qua_Time;
my $tcpar_Fault_Voltage;
my $tcpar_Fault_Voltage_State;
my $tcpar_ProveOut_Time;
my $tcpar_DHSWL_signal;

################ global parameter declaration ###################
#add any global variables here


###############################################################

sub TC_set_parameters {

	$tcpar_purpose =  GEN_Read_mandatory_testcase_parameter( 'purpose' );
	$tcpar_Voltage =  GEN_Read_mandatory_testcase_parameter( 'Voltage' );
	$tcpar_Fault =  GEN_Read_mandatory_testcase_parameter( 'Fault' );
	$tcpar_Fault_state =  GEN_Read_mandatory_testcase_parameter( 'Fault_state' );
	$tcpar_Fault_Qua_Time =  GEN_Read_mandatory_testcase_parameter( 'Fault_Qua_Time' );
	$tcpar_Fault_Voltage =  GEN_Read_mandatory_testcase_parameter( 'Fault_Voltage' );
	$tcpar_Fault_Voltage_State =  GEN_Read_mandatory_testcase_parameter( 'Fault_Voltage_State' );
	$tcpar_ProveOut_Time =  GEN_Read_mandatory_testcase_parameter( 'ProveOut_Time' );
	$tcpar_DHSWL_signal =  GEN_Read_mandatory_testcase_parameter( 'DHSWL_signal' );

	return 1;
}

sub TC_initialization {

	S_teststep("StandardPrepNoFault", 'AUTO_NBR');
	GEN_StandardPrepNoFault();

	return 1;
}

sub TC_stimulation_and_measurement {

	S_teststep("Set The voltage to '$tcpar_Voltage' and check fault recorder.", 'AUTO_NBR', 'set_the_voltage');			#measurement 1

	S_teststep("Create '$tcpar_Fault' condition to keep ECU in ITM mode after '$tcpar_ProveOut_Time' and wait for '$tcpar_Fault_Qua_Time'.", 'AUTO_NBR');

	S_teststep("Reset ECU.", 'AUTO_NBR');

	S_teststep("Wait for '$tcpar_ProveOut_Time'", 'AUTO_NBR');

	S_teststep("Check fault recorder.", 'AUTO_NBR', 'check_fault_recorder');			#measurement 2

	S_teststep("Check ECU mode.", 'AUTO_NBR', 'check_ecu_mode');			#measurement 3

	S_teststep("Check state of '$tcpar_DHSWL_signal' at '$tcpar_ProveOut_Time' continuously from IGN ON.", 'AUTO_NBR', 'check_state_of');			#measurement 4

	return 1;
}

sub TC_evaluation {

	S_teststep_expected("'$tcpar_Fault_Voltage' is in '$tcpar_Fault_Voltage_state'.", 'set_the_voltage');			#evaluation 1
	S_teststep_detected("<<add detected result here>>", 'set_the_voltage');

	S_teststep_expected("'$tcpar_Fault' is in '$tcpar_Fault_state' and '$tcpar_Fault_Voltage' in '$tcpar_Fault_Voltage_State'.", 'check_fault_recorder');			#evaluation 2
	S_teststep_detected("<<add detected result here>>", 'check_fault_recorder');

	S_teststep_expected("ECU goes to ITM mode.", 'check_ecu_mode');			#evaluation 3
	S_teststep_detected("<<add detected result here>>", 'check_ecu_mode');

	S_teststep_expected("'$tcpar_DHSWL_signal' shall be 0x1.", 'check_state_of');			#evaluation 4
	S_teststep_detected("<<add detected result here>>", 'check_state_of');

	return 1;
}

sub TC_finalization {

	return 1;
}


1;
