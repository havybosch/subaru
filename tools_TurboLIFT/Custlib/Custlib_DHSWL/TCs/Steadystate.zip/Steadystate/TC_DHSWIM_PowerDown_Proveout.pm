#### TEST CASE MODULE
package TC_DHSWIM_PowerDown_Proveout;

#### DONT MODIFY THIS SECTION ####
use strict;
use warnings;

###-------------------------------###
our $VERSION = q$Revision: 1.1 $;
our $HEADER = q$Header: Include/TCpmGenerator/Create_TCpm.pl 1.1 2015/01/21 16:00:45MEZ Geisler Martin (CC-PS/EPS2) (gem1si) develop  $;

#----------------------- TEST SPECIFICATION ------------------------------
#This script is based on TS: <TS name> (e.g. TS_SWM_SwitchMgt)
#TS version in DOORS: <TS version based on which this script is written/updated> (e.g. 3.30)
#-------------------------------------------------------------------------

#### INCLUDE ENGINE MODULES ####

use LIFT_general;
use INCLUDES_Project; #necessary
#include further modules here
use LIFT_labcar;
use LIFT_can_access;
use FuncLib_TNT_FM;
use LIFT_evaluation;
use LIFT_PD;
use GENERIC_DCOM;

##################################

our $PURPOSE = "<summarize what this test is good for>";

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> DOCUMENTATION >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

=head1 TESTCASE MODULE

TC_DHSWIM_PowerDown_Proveout

=head1 PURPOSE

<explain what this test is good for>

=head1 TESTCASE DESCRIPTION


I<B<Initialisation>>

StandardPrepNoFault


I<B<Stimulation and Measurement>>

1. Set voltage to <Condition>

2. IGN off

3. Wait for ECU off

4. IGN on

5. Wait for <time1> and turn off ECU

6. Read WL status <DHSWL_signal> until power is off completely

7. IGN on

8. Wait for <time2> and turn off ECU

9. Read WL status <DHSWL_signal> since step 7 until power is off completely

10. IGN on

11. Wait for <time3> and turn off ECU

12. Read WL status <DHSWL_signal> since step 10 until power is off completely


I<B<Evaluation>>

1. 

2. 

3. 

4. 

5. 

6. <DHSWL_signal> shall be in <Value_On> for <time_proveout_on> from IGNON, and keep <Value_Off> since <time_proveout_on> till power off completely

7. 

8.

9. <DHSWL_signal> shall be in shall be in <Value_On> for <time_proveout_on> since IGN on, and keep <Value_Off> since <time_proveout_on> till power off

10.

11.

12. <DHSWL_signal> shall be in <Value_On> since IGN on till power off completely 


I<B<Finalisation>>

Reset/Remove the test condition created in test case


=head1 PARAMETER DESCRIPTION


=head2 PARAMETER NAMES

	SCALAR 'purpose' => 
	SCALAR 'DHSWL_signal' => 
	SCALAR 'Condition' => 
	SCALAR 'Value_Off' => 
	SCALAR 'Value_On' => 
	SCALAR 'time1' => 
	SCALAR 'time_proveout_on' => 
	SCALAR 'time2' => 
	SCALAR 'time3' => 


=head2 PARAMETER EXAMPLES

	purpose = 'check behavior of DHSWL when power is cut off in Prove out mode'
	
	DHSWL_signal = 'DHS_RILReq'
	Condition = '<Test Heading 2>'
	Value_Off = '0'
	Value_On = '1'
	
	time1 = '4000' #ms
	time_proveout_on = '6000' #ms (+/-150ms)
	time2 = '6500' #ms
	time3 = '2000' #ms (+/-150ms)

=cut



#PARAMETERS
################ Parameters from .par file ###################
my $tcpar_purpose;
my $tcpar_DHSWL_signal;
my $tcpar_Condition;
my $tcpar_Value_Off;
my $tcpar_Value_On;
my $tcpar_time1;
my $tcpar_time_proveout_on;
my $tcpar_time2;
my $tcpar_time3;

################ global parameter declaration ###################
#add any global variables here
my $fault_struct;
my $Provetime_Obt;
my $Provetime_Obt_after;
my $Provetime_Obt_last;
my @Provetime_Obt_arr;
my @Provetime_Obt_after_arr;
my @Provetime_Obt_last_arr;

###############################################################

sub TC_set_parameters {

	$tcpar_purpose =  GEN_Read_mandatory_testcase_parameter( 'purpose' );
	$tcpar_DHSWL_signal =  GEN_Read_mandatory_testcase_parameter( 'DHSWL_signal' );
	$tcpar_Condition =  GEN_Read_mandatory_testcase_parameter( 'Condition' );
	$tcpar_Value_Off =  GEN_Read_mandatory_testcase_parameter( 'Value_Off' );
	$tcpar_Value_On =  GEN_Read_mandatory_testcase_parameter( 'Value_On' );
	$tcpar_time1 =  GEN_Read_mandatory_testcase_parameter( 'time1' );
	$tcpar_time_proveout_on =  GEN_Read_mandatory_testcase_parameter( 'time_proveout_on' );
	$tcpar_time2 =  GEN_Read_mandatory_testcase_parameter( 'time2' );
	$tcpar_time3 =  GEN_Read_mandatory_testcase_parameter( 'time3' );

	return 1;
}

sub TC_initialization {


	S_teststep( "StandardPrepNoFault", 'AUTO_NBR' );
	CA_trace_start();
	GEN_StandardPrepNoFault();

	return 1;
}

sub TC_stimulation_and_measurement {

	S_teststep("Set voltage to '$tcpar_Condition'", 'AUTO_NBR');
        LC_ECU_On();
	   	if ($tcpar_Condition eq 'NormalVoltage') {
    		LC_SetVoltage(12);
    	}
    	elsif ($tcpar_Condition eq 'LowVoltage') {
    		LC_SetVoltage(7);
    	}
    	else {
    	 	LC_SetVoltage(17);
    	}
    	S_wait_ms( 2000 );

		$fault_struct = PD_ReadFaultMemory(1);
    	
    	#### check fault Voltage ###
      	push( my @flt, @{ $fault_struct->{'fault_text'} } );
        push( my @DTC, @{ $fault_struct->{'state'} } );
 	   	if ($tcpar_Condition eq 'NormalVoltage') {
             EVAL_evaluate_string("To check whether system has no voltage fault or not", '$flt[0]', '' );
	   	}
		elsif ($tcpar_Condition eq 'LowVoltage') {
             EVAL_evaluate_string("To check whether low voltage fault name or not", '$flt[0]', 'rb_pom_VbatLow_flt' );
             if ( $DTC[0] eq '0xaf' or $DTC[0] eq '0x2f' ) {
             		EVAL_evaluate_string("To check whether low voltage fault is Qualified or not",	'Qualified', 'Qualified' );
             }
             else {
             		EVAL_evaluate_string("To check whether low voltage fault is Qualified or not",	'Not Qualified', 'Qualified' );
             }					
        }  
        else {             
        	 EVAL_evaluate_string("To check whether high voltage fault name or not", '$flt[0]', 'rb_pom_VbatHigh_flt' );
             if ( $DTC[0] eq '0xaf' or $DTC[0] eq '0x2f' ) {
             		EVAL_evaluate_string("To check whether high voltage fault is Qualified or not",	'Qualified', 'Qualified' );
             }
             else {
             		EVAL_evaluate_string("To check whether high voltage fault is Qualified or not",	'Not Qualified', 'Qualified' );
             }					
        }      
    	#### finish check fault Voltage ###        
        

            	
    	
    	
    	
    		

	S_teststep("IGN off", 'AUTO_NBR');
		LC_ECU_Off();

	S_teststep("Wait for ECU off", 'AUTO_NBR');
    	S_wait_ms( 'TIMER_ECU_OFF' );
	

	S_teststep("IGN on", 'AUTO_NBR');
        LC_ECU_On();
	

	S_teststep("Wait for '$tcpar_time1' and turn off ECU", 'AUTO_NBR');
    	S_wait_ms( $tcpar_time1 );	
		LC_ECU_Off();
    		

	S_teststep("Read WL status '$tcpar_DHSWL_signal' until power is off completely", 'AUTO_NBR', 'read_wl_status_A');			#measurement 1
	     foreach ( 1 .. 8 ) { S_w2rep( "Get the '$tcpar_DHSWL_signal' prove out in step $_\n",'blue' );
		  $Provetime_Obt = CA_read_can_signal($tcpar_DHSWL_signal, 'hex' );
		  $Provetime_Obt =~ s/0x//;
		 push( @Provetime_Obt_arr, hex($Provetime_Obt) );
		}
		
    	S_wait_ms( 'TIMER_ECU_OFF' );
		
		
	S_teststep("IGN on", 'AUTO_NBR');
        LC_ECU_On();
	

	S_teststep("Wait for '$tcpar_time2' and turn off ECU", 'AUTO_NBR');
    	S_wait_ms( $tcpar_time2 );	
		LC_ECU_Off();	

	S_teststep("Read WL status '$tcpar_DHSWL_signal' since step 7 until power is off completely", 'AUTO_NBR', 'read_wl_status_B');			#measurement 2
	     foreach ( 1 .. 8 ) { S_w2rep( "Get the '$tcpar_DHSWL_signal' prove out in step $_\n",'blue' );
		  $Provetime_Obt_after = CA_read_can_signal($tcpar_DHSWL_signal, 'hex' );
		  $Provetime_Obt_after =~ s/0x//;
		 push( @Provetime_Obt_after_arr, hex($Provetime_Obt_after) );
		 }
    	S_wait_ms( 'TIMER_ECU_OFF' );
		 
	S_teststep("IGN on", 'AUTO_NBR');
        LC_ECU_On();

	S_teststep("Wait for '$tcpar_time3' and turn off ECU", 'AUTO_NBR');
    	S_wait_ms( $tcpar_time3 );	

	S_teststep("Read WL status '$tcpar_DHSWL_signal' since step 10 until power is off completely", 'AUTO_NBR', 'read_wl_status_C');			#measurement 3
	     foreach ( 1 .. 8 ) { S_w2rep( "Get the '$tcpar_DHSWL_signal' prove out in step $_\n",'blue' );
		  $Provetime_Obt_last = CA_read_can_signal($tcpar_DHSWL_signal, 'hex' );
		  $Provetime_Obt_last =~ s/0x//;
		 push( @Provetime_Obt_last_arr, hex($Provetime_Obt_last) );
		 }
		 
		 
	return 1;
}

sub TC_evaluation {

	S_teststep_expected("'$tcpar_DHSWL_signal' shall be in '$tcpar_Value_On' for '$tcpar_time_proveout_on' from IGNON, and keep '$tcpar_Value_Off' since '$tcpar_time_proveout_on' till power off completely", 'read_wl_status_A');			#evaluation 1
	S_teststep_detected("'$tcpar_DHSWL_signal' is observed by followings:  ", 'read_wl_status_A');
	   foreach (@Provetime_Obt_arr) {
	   EVAL_evaluate_value( "Observed value in Autarky time :", $_, "==", $tcpar_Value_On );
	   }	

	S_teststep_expected("'$tcpar_DHSWL_signal' shall be in shall be in '$tcpar_Value_On' for '$tcpar_time_proveout_on' since IGN on, and keep '$tcpar_Value_Off' since '$tcpar_time_proveout_on' till power off", 'read_wl_status_B');			#evaluation 2
	S_teststep_detected("'$tcpar_DHSWL_signal' is observed by followings: ", 'read_wl_status_B');
	   foreach (@Provetime_Obt_after_arr) {
	   EVAL_evaluate_value( "Observed value in Autarky time :", $_, "==", $tcpar_Value_Off );
	   }		

	S_teststep_expected("'$tcpar_DHSWL_signal' shall be in '$tcpar_Value_On' since IGN on till power off completely ", 'read_wl_status_C');			#evaluation 3
	S_teststep_detected("'$tcpar_DHSWL_signal' is observed by followings: ", 'read_wl_status_C');
	   foreach (@Provetime_Obt_last_arr) {
	   EVAL_evaluate_value( "Observed value in Autarky time :", $_, "==", $tcpar_Value_On );
	   }		

	return 1;
}

sub TC_finalization {
	S_wait_ms(2000);
	PD_ClearFaultMemory();
	S_wait_ms(5000);
	return 1;
}


1;
